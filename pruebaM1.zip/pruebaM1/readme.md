# INVENTARIO RIWI

** Funcionalidades **
* Tiene dos menús. El primero menú la primera opción es para elegir si desea ingresar productos (Solo permite ingresas 5 productos o más), la segunda opción es para ingresar al segundo menú, y la tercera opción es para salir del programa

* Al ingresar al segundo menú se despliegan otras funcionalidades.
* 1.Agregar de a un solo producto 2.Consultar disponibilidad de un producto 3.Actualizar precio de un producto 4.Eliminar un producto del inventario 5.Mostrar el valor total de todo el inventario (precio*cantidad) y muestra la suma de todos 6.Muestra todo el inventario actualizado 

# Datos de entrada 



